/** Package-owned invariant companion for the local knowledge backend. @module @deepseek-ai/dsh-knowledge-local/invariant */
import type { Context } from '@deepseek-ai/cordis';
export declare const name = "knowledge-local-invariant";
export declare const inject: string[];
export declare const apply: (ctx: Context) => Promise<() => void>;
//# sourceMappingURL=invariant.d.ts.map