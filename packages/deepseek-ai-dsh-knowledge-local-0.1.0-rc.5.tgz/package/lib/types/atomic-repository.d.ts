import { NoteId, type AttachmentView, type CanvasRef, type CanvasView, type CreateNoteRequest, type GraphView, type KnowledgeBackend, type NoteLinksView, type NoteRef, type NoteRevisionRef, type NoteSummary, type NoteView, type OpenVaultRequest, type PutAttachmentRequest, type RenameNoteRequest, type RestoreNoteRequest, type SaveCanvasRequest, type SaveGraphRequest, type SaveNoteRequest, type SearchHit, type SearchRequest, type TrashReceipt, type VaultId as VaultIdType, type VaultView } from '@deepseek-ai/dsh-knowledge';
/** Contract describing local knowledge config in Knowledge Studio. */
export interface LocalKnowledgeConfig {
    /** Existing vault directories allowed for this backend. */
    readonly roots?: readonly string[];
    /** Vault directory mounted on startup. */
    readonly defaultRoot?: string;
    /** Maximum UTF-8 bytes accepted for one note. */
    readonly maxNoteBytes?: number;
    /** Days to retain notes in the vault trash. */
    readonly trashRetentionDays?: number;
    /** Whether external Markdown changes are observed. */
    readonly watch?: boolean;
    /** Delay used to coalesce file change notifications. */
    readonly debounceMs?: number;
    /** Drive letters that may contain a vault. */
    readonly allowedDrives?: readonly ('D:' | 'G:')[];
    /** Callback for note revision notifications. */
    readonly onChanged?: (event: KnowledgeChanged) => void;
    /** Deterministic hooks used only by repository tests. */
    readonly testHooks?: {
        /** Observe the target immediately before an atomic rename publishes it. */
        readonly beforeRenamePublish?: (ordinal: number, target: string) => void;
    };
}
/** JSON-safe note revision notification emitted by the local repository. */
export interface KnowledgeChanged {
    /** Vault owning the changed note. */
    readonly vaultId: string;
    /** Changed note identifier. */
    readonly noteId: string;
    /** Newly published revision hash. */
    readonly revision: string;
}
/** Implements local knowledge backend for Knowledge Studio. */
export declare class LocalKnowledgeBackend implements KnowledgeBackend {
    private readonly config;
    private readonly vaults;
    private watcher;
    private closed;
    private constructor();
    /**
     * Create for Knowledge Studio.
     * @param config - The config input.
     * @returns The operation result.
     */
    static create(config: LocalKnowledgeConfig): Promise<LocalKnowledgeBackend>;
    /** Close for Knowledge Studio. */
    close(): Promise<void>;
    listVaults(): Promise<readonly VaultView[]>;
    openVault(request: OpenVaultRequest): Promise<VaultView>;
    listNotes(vaultId: VaultIdType): Promise<readonly NoteSummary[]>;
    getNote(ref: NoteRef): Promise<NoteView>;
    createNote(request: CreateNoteRequest): Promise<NoteView>;
    saveNote(request: SaveNoteRequest): Promise<NoteView>;
    renameNote(request: RenameNoteRequest): Promise<NoteView>;
    trashNote(ref: NoteRevisionRef): Promise<TrashReceipt>;
    restoreNote(request: RestoreNoteRequest): Promise<NoteView>;
    search(request: SearchRequest): Promise<readonly SearchHit[]>;
    links(ref: NoteRef): Promise<NoteLinksView>;
    putAttachment(request: PutAttachmentRequest): Promise<AttachmentView>;
    /**
     * Read attachment for Knowledge Studio.
     * @param vaultId - The vault id input.
     * @param noteId - The note id input.
     * @param filename - The filename input.
     * @returns The operation result.
     */
    readAttachment(vaultId: VaultIdType, noteId: NoteId, filename: string): Promise<{
        mediaType: string;
        bytes: Buffer;
    }>;
    getCanvas(ref: CanvasRef): Promise<CanvasView>;
    saveCanvas(request: SaveCanvasRequest): Promise<CanvasView>;
    getGraph(vaultId: VaultIdType): Promise<GraphView>;
    saveGraph(request: SaveGraphRequest): Promise<GraphView>;
    /**
     * Debug owned note paths for Knowledge Studio.
     * @param vaultId - The vault id input.
     * @returns The operation result.
     */
    debugOwnedNotePaths(vaultId: VaultIdType): Promise<readonly string[]>;
    private mount;
    private state;
    private record;
    private vaultView;
    private readNote;
    private noteView;
    private commitNote;
    private allNotes;
    private writeLinkIndex;
    private commitRenameBatch;
    private assertSize;
    private saveManifest;
    private mutate;
    private publishExternal;
}
//# sourceMappingURL=atomic-repository.d.ts.map