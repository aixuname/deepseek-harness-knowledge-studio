import { type AttachmentView, type PutAttachmentRequest } from '@deepseek-ai/dsh-knowledge';
import { type CanonicalVaultRoot } from './paths.ts';
/** Max image bytes for Knowledge Studio. */
export declare const MAX_IMAGE_BYTES: number;
/** Accepted image mime for Knowledge Studio. */
export declare const ACCEPTED_IMAGE_MIME: Set<string>;
/**
 * Safe asset name for Knowledge Studio.
 * @param input - The input input.
 * @returns The operation result.
 */
export declare function safeAssetName(input: string): string;
/**
 * Read only a note-owned image filename; never accept a caller's path.
 * @param root - Canonical vault root for the owning note.
 * @param noteId - Identifier of the note owning the attachment.
 * @param filename - Generated attachment filename, not a path.
 * @returns Verified image bytes and MIME type.
 */
export declare function readAttachment(root: CanonicalVaultRoot, noteId: string, filename: string): Promise<{
    mediaType: string;
    bytes: Buffer;
}>;
/**
 * Store attachment for Knowledge Studio.
 * @param root - The root input.
 * @param request - The request input.
 * @returns The operation result.
 */
export declare function storeAttachment(root: CanonicalVaultRoot, request: PutAttachmentRequest): Promise<AttachmentView>;
//# sourceMappingURL=assets.d.ts.map