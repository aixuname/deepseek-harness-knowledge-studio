import { type GraphView, type SaveGraphRequest, type VaultId } from '@deepseek-ai/dsh-knowledge';
import { type CanonicalVaultRoot } from './paths.ts';
/** Read a vault-owned graph without modifying notes or creating a graph file.
 * @param root Canonical vault root.
 * @param vaultId Vault identity.
 * @returns Current graph and revision.
 */
export declare function readGraph(root: CanonicalVaultRoot, vaultId: VaultId): Promise<GraphView>;
/** Atomically replace a vault graph if its revision is unchanged.
 * @param root Canonical vault root.
 * @param request Revisioned graph replacement.
 * @returns Saved graph with its new revision.
 */
export declare function writeGraph(root: CanonicalVaultRoot, request: SaveGraphRequest): Promise<GraphView>;
//# sourceMappingURL=graph.d.ts.map