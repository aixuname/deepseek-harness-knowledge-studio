import { type CanvasRef, type CanvasView, type NoteId, type SaveCanvasRequest } from '@deepseek-ai/dsh-knowledge';
import { type CanonicalVaultRoot } from './paths.ts';
/** Contract describing stored canvas document in Knowledge Studio. */
export interface StoredCanvasDocument {
    readonly type: 'excalidraw';
    readonly version: 1;
    readonly noteId: NoteId;
    readonly elements: readonly unknown[];
    readonly appState: Readonly<Record<string, unknown>>;
    readonly files: Readonly<Record<string, unknown>>;
}
/**
 * Read canvas for Knowledge Studio.
 * @param root - The root input.
 * @param ref - The ref input.
 * @returns The operation result.
 */
export declare function readCanvas(root: CanonicalVaultRoot, ref: CanvasRef): Promise<CanvasView>;
/**
 * Write canvas for Knowledge Studio.
 * @param root - The root input.
 * @param request - The request input.
 * @returns The operation result.
 */
export declare function writeCanvas(root: CanonicalVaultRoot, request: SaveCanvasRequest): Promise<CanvasView>;
//# sourceMappingURL=canvases.d.ts.map