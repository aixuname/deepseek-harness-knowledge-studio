import type { KnowledgeRevision } from '@deepseek-ai/dsh-knowledge';
/** Contract describing file observation in Knowledge Studio. */
export interface FileObservation {
    readonly path: string;
    readonly revision: KnowledgeRevision;
}
/** Implements file observation debouncer for Knowledge Studio. */
export declare class FileObservationDebouncer {
    private readonly delayMs;
    private readonly publish;
    private readonly committed;
    private readonly pending;
    constructor(delayMs: number, publish: (event: FileObservation) => void);
    /**
     * Mark committed for Knowledge Studio.
     * @param path - The path input.
     * @param revision - The revision input.
     */
    markCommitted(path: string, revision: KnowledgeRevision): void;
    /**
     * Observe for Knowledge Studio.
     * @param event - The event input.
     */
    observe(event: FileObservation): void;
    /** Close for Knowledge Studio. */
    close(): void;
}
/** Implements knowledge file watcher for Knowledge Studio. */
export declare class KnowledgeFileWatcher {
    private readonly observer;
    private readonly watcher;
    /** Ready for Knowledge Studio. */
    readonly ready: Promise<void>;
    constructor(paths: readonly string[], delayMs: number, publish: (event: FileObservation) => void);
    /**
     * Mark committed for Knowledge Studio.
     * @param path - The path input.
     * @param revision - The revision input.
     */
    markCommitted(path: string, revision: KnowledgeRevision): void;
    /** Close for Knowledge Studio. */
    close(): Promise<void>;
    private read;
}
//# sourceMappingURL=watcher.d.ts.map