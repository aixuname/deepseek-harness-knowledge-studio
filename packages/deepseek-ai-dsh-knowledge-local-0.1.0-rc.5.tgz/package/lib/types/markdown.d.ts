import { KnowledgeRevision, type NoteId as NoteIdType } from '@deepseek-ai/dsh-knowledge';
/** Contract describing parsed note in Knowledge Studio. */
export interface ParsedNote {
    readonly id: NoteIdType;
    readonly title: string;
    readonly tags: readonly string[];
    readonly createdAt: number;
    readonly updatedAt: number;
    readonly body: string;
}
/**
 * Parse note for Knowledge Studio.
 * @param source - The source input.
 * @returns The operation result.
 */
export declare function parseNote(source: string): ParsedNote;
/**
 * Serialize note for Knowledge Studio.
 * @param note - The note input.
 * @returns The operation result.
 */
export declare function serializeNote(note: ParsedNote): string;
/**
 * Note revision for Knowledge Studio.
 * @param bytes - The bytes input.
 * @returns The operation result.
 */
export declare function noteRevision(bytes: Uint8Array): KnowledgeRevision;
//# sourceMappingURL=markdown.d.ts.map