/** Contract describing canonical vault root in Knowledge Studio. */
export interface CanonicalVaultRoot {
    readonly displayPath: string;
    readonly realPath: string;
    readonly drive: 'D:' | 'G:';
}
/**
 * Resolve allowed vault root for Knowledge Studio.
 * @param input - The input input.
 * @param allowedDrives - The allowed drives input.
 * @returns The operation result.
 */
export declare function resolveAllowedVaultRoot(input: string, allowedDrives?: readonly ('D:' | 'G:')[]): Promise<CanonicalVaultRoot>;
/**
 * Resolve owned path for Knowledge Studio.
 * @param root - The root input.
 * @param manifestPath - The manifest path input.
 * @returns The operation result.
 */
export declare function resolveOwnedPath(root: CanonicalVaultRoot, manifestPath: string): string;
//# sourceMappingURL=paths.d.ts.map