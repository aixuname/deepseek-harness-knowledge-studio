/** Guarded local Markdown persistence for Knowledge Studio. @module @deepseek-ai/dsh-knowledge-local */
import type { Context } from '@deepseek-ai/cordis';
import { type KnowledgeChanged, type LocalKnowledgeConfig } from './atomic-repository.ts';
declare module '@deepseek-ai/cordis' {
    interface Events {
        /**
         * A note revision was published; listeners may refresh their local view.
         * @mode emit
         * @param event - The changed note and its new revision.
         */
        'knowledge/changed'(event: KnowledgeChanged): void;
    }
}
export * from './paths.ts';
export * from './markdown.ts';
export * from './watcher.ts';
export * from './links.ts';
export * from './assets.ts';
export * from './canvases.ts';
export * from './graph.ts';
export * from './atomic-repository.ts';
export declare const name = "knowledge-local";
export declare const inject: string[];
export declare function apply(ctx: Context, config: LocalKnowledgeConfig): Promise<() => Promise<void>>;
//# sourceMappingURL=index.d.ts.map