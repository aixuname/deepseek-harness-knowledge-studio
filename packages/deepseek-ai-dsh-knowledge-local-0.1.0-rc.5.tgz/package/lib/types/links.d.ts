import type { NoteId, NoteLinksView, NoteSummary, NoteView, SearchHit, SearchRequest, VaultId } from '@deepseek-ai/dsh-knowledge';
/** Contract describing wiki link in Knowledge Studio. */
export interface WikiLink {
    readonly raw: string;
    readonly title: string;
    readonly from: number;
    readonly to: number;
}
/** Contract describing link index in Knowledge Studio. */
export interface LinkIndex {
    readonly version: 1;
    readonly notes: Readonly<Record<string, {
        readonly title: string;
        readonly outgoing: readonly NoteId[];
        readonly unresolved: readonly string[];
        readonly labels: readonly string[];
        readonly targets: readonly (NoteId | null)[];
    }>>;
}
/**
 * Parse wiki links for Knowledge Studio.
 * @param markdown - The markdown input.
 * @returns The operation result.
 */
export declare function parseWikiLinks(markdown: string): readonly WikiLink[];
/**
 * Rewrite wiki link title for Knowledge Studio.
 * @param markdown - The markdown input.
 * @param oldTitle - The old title input.
 * @param newTitle - The new title input.
 * @returns The operation result.
 */
export declare function rewriteWikiLinkTitle(markdown: string, oldTitle: string, newTitle: string): string;
/**
 * Build link index for Knowledge Studio.
 * @param notes - The notes input.
 * @returns The operation result.
 */
export declare function buildLinkIndex(notes: readonly NoteView[]): LinkIndex;
/**
 * Link view for Knowledge Studio.
 * @param index - The index input.
 * @param vaultId - The vault id input.
 * @param noteId - The note id input.
 * @returns The operation result.
 */
export declare function linkView(index: LinkIndex, vaultId: VaultId, noteId: NoteId): NoteLinksView;
/**
 * Rank search for Knowledge Studio.
 * @param notes - The notes input.
 * @param request - The request input.
 * @returns The operation result.
 */
export declare function rankSearch(notes: readonly NoteSummary[], request: SearchRequest): readonly SearchHit[];
//# sourceMappingURL=links.d.ts.map