# @deepseek-ai/dsh-knowledge-local

English | [中文](README.zh.md)

Provides guarded, revisioned Markdown persistence for Knowledge Studio. Vault roots are canonicalized before use and restricted to configured drives. Note identifiers resolve only through a package-owned manifest, so Remote input never becomes a filesystem path.

Writes use same-directory atomic replacement and a per-vault mutation queue. Exact content hashes provide compare-and-set saves, stale edits retain both disk and draft content, deletion moves recoverable data into a vault-local trash tree, and complete external edits publish a change event.

The backend derives WikiLink backlinks and deterministic ranked search from independent notes. Transactional renames update inbound text links without touching code spans. Validated image attachments and one revisioned Excalidraw document per note remain isolated and move through trash and restore with their owner. One vault-scoped `.dsh-knowledge/graph.json` stores manually positioned note nodes and labeled edges separately from Markdown; stale writes fail without replacing the graph.

## Model Experience

None, as this package persists knowledge files and publishes storage changes without assembling prompts or invoking a model.

#### KV Cache effect

None; no model input is produced.

## Known Limitations and Deferred Work

- Attachments accept PNG, JPEG, WebP, and GIF images up to 20 MiB; other media types are deferred.
- Canvas documents are capped at 5 MiB and reject missing file references, unsafe asset URLs, excessive nesting, and unstable note-card identifiers.
- A relationship graph is capped at 1 MiB, 500 nodes, and 1000 edges; references must belong to the owning vault, including recoverable trashed notes.
- Junction creation tests are skipped with an explicit capability reason when the current Windows token lacks symlink privileges.
