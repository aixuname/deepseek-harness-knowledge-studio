# @deepseek-ai/dsh-client-ui-surface

English | [中文](README.zh.md)

Reusable top-level application surfaces for the DeepSeek Harness browser. The plugin provides `ctx.appSurfaces`, keeps one ordered registry for independently owned pages, and contributes one additive host to the existing `shell.overlay` slot. Opening a surface covers only the center and details regions; the sidebar remains available and the chat subtree stays mounted, preserving drafts, scroll position, and session-local component state.

Register a page from another Client plugin's apply function, then dispose the returned callback with that plugin's lifecycle. IDs are unique stable lowercase identifiers, and entries sort by `order` then ID. `open(id)` fails for an unavailable page. Removing an active definition closes it before withdrawal, so no orphaned selection remains after unload or HMR.

The host makes the obscured center and details regions inert and `aria-hidden`, focuses the active page, closes it on Escape, and restores both prior DOM attributes and the user's previous focus. It uses `--dsh-sidebar-width`, published by `ui-layout`, so wide, compact-rail, and narrow sidebar states all produce the same boundary without replacing any existing slot occupant. Reduced-motion preferences disable the page entrance animation.

The `/client` entry exports only the Cordis plugin body and surface contract types. Viewing state lives in the feature-owned observable registry, so the package needs no host-runtime store module. The page host and concrete registry implementation remain package-internal.

## Model Experience

### Surface navigation

#### What the model sees

Nothing. Operations through `ctx.appSurfaces` manage browser viewing state and never assemble, modify, or send model input.

#### Token effect

None. Opening, switching, and closing surfaces perform no model call and add no messages, tools, or context.

#### KV Cache effect

None; opening or closing an application surface does not change any provider request.

## Known Limitations and Deferred Work

- The selected page survives component remounts for the lifetime of the Client plugin, but is intentionally not restored after a full browser reload.
- A surface definition carries a React component in the in-process registry and is therefore a browser-only contract; it is never serialized or sent over Remote.
- The generic host owns only page lifecycle and accessibility isolation. Page-specific navigation, unsaved-work prompts, and responsive columns belong to the registering plugin.
