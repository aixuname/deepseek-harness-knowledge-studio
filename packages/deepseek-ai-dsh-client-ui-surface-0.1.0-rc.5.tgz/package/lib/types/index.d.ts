/** Host loader entry for the browser-only application-surface plugin. */
/** Provides no Host-side behavior. */
export declare function apply(): void;
//# sourceMappingURL=index.d.ts.map