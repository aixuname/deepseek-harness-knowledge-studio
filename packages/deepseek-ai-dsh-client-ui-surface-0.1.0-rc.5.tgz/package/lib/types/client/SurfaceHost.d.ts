import type { InjectFace, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { AppSurfaceRegistry } from './service.ts';
export interface SurfaceHostInjected {
    readonly hooks: {
        readonly appSurfaces: AppSurfaceRegistry;
    };
    readonly closeSurface: () => void;
}
export type SurfaceHostProps = PropsRuntime<'shell.overlay'> & InjectFace<SurfaceHostInjected>;
/** Full-page host layered over center/details without replacing either subtree. */
export declare function SurfaceHost({ useAppSurfaces, closeSurface }: SurfaceHostProps): import("react").JSX.Element | null;
//# sourceMappingURL=SurfaceHost.d.ts.map