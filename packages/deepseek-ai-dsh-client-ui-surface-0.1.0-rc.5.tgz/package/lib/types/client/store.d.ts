import { type EngineStoreHandle } from '@deepseek-ai/dsh-client-runtime/client';
/** Serializable viewing state owned by the mounted surface host. */
export interface AppSurfaceState {
    active: string | null;
}
type AppSurfaceActions = {
    open: (draft: AppSurfaceState, id: string) => void;
    close: (draft: AppSurfaceState) => void;
};
/**
 * Create the root-scoped surface viewing store.
 * @param onActiveChanged - synchronously mirrors committed gestures to the registry service.
 */
export declare function createAppSurfaceStore(onActiveChanged?: (active: string | undefined) => void): EngineStoreHandle<AppSurfaceState, AppSurfaceActions>;
export {};
//# sourceMappingURL=store.d.ts.map