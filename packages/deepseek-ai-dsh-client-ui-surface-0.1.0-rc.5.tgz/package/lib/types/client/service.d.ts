import type { ComponentType } from 'react';
import type { SnapshotSelectorHook } from '@deepseek-ai/dsh-client-ui-slots';
/** Props every registered full-page application surface receives. */
export interface AppSurfaceProps {
    readonly close: () => void;
}
/** One independently owned top-level page. */
export interface AppSurfaceDefinition {
    readonly id: string;
    readonly title: string;
    readonly order: number;
    readonly component: ComponentType<AppSurfaceProps>;
}
/** Stable observable snapshot consumed by the framework-bound surface hook. */
export interface AppSurfaceSnapshot {
    readonly active: string | undefined;
    readonly entries: readonly AppSurfaceDefinition[];
    readonly revision: number;
}
/** Public registry face exposed as `ctx.appSurfaces`. */
export interface AppSurfaceRegistry {
    register(definition: AppSurfaceDefinition): () => void;
    open(id: string): void;
    close(): void;
    active(): string | undefined;
    entries(): readonly AppSurfaceDefinition[];
    getSnapshot(): AppSurfaceSnapshot;
    subscribe(listener: () => void): () => void;
}
/** Contract describing use app surfaces in Knowledge Studio. */
export type UseAppSurfaces = SnapshotSelectorHook<AppSurfaceSnapshot>;
/** Cordis-owned registry and observable definition ledger. */
export declare class AppSurfaceController implements AppSurfaceRegistry {
    #private;
    register(definition: AppSurfaceDefinition): () => void;
    open(id: string): void;
    close(): void;
    active(): string | undefined;
    entries(): readonly AppSurfaceDefinition[];
    getSnapshot: () => AppSurfaceSnapshot;
    subscribe: (listener: () => void) => (() => void);
    /**
     * Mirror a page transition into the public observable face.
     * @param active - Newly active surface, or undefined for the chat view.
     */
    syncActive(active: string | undefined): void;
}
//# sourceMappingURL=service.d.ts.map