import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
export type { AppSurfaceDefinition, AppSurfaceProps, AppSurfaceRegistry, AppSurfaceSnapshot, } from './service.ts';
declare module '@deepseek-ai/cordis' {
    interface Context {
        appSurfaces: import('./service.ts').AppSurfaceRegistry;
    }
}
/** Runtime services consumed by this browser plugin. */
export declare const inject: string[];
/** Provide the registry and contribute one additive host to `shell.overlay`. */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map