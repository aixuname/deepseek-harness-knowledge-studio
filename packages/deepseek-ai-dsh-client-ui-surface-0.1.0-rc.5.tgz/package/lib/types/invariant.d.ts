/** Package-owned invariant companion for `@deepseek-ai/dsh-client-ui-surface`. */
import type { Context } from '@deepseek-ai/cordis';
/** Cordis companion plugin name. */
export declare const name = "client-ui-surface-invariant";
/** Service required before package ownership can be reserved. */
export declare const inject: string[];
/** Register this package's invariant companion. */
export declare const apply: (ctx: Context) => Promise<() => void>;
//# sourceMappingURL=invariant.d.ts.map