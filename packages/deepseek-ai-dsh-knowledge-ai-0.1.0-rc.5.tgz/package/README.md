# @deepseek-ai/dsh-knowledge-ai

English | [中文](README.zh.md)

Provides the Knowledge Studio copilot behind the existing `knowledge.*` Remote namespace. It selects a small, inspectable context for one note, records the exact model-visible excerpts in that note's hidden session, and returns a reviewable Markdown diff proposal. Generation never writes a note; applying selected hunks performs a compare-and-set save against the proposal's base revision.

Each note owns one durable session id, `knowledge:<vaultId>:<noteId>`, with `origin: 'knowledge'`. Host chat listing and search omit that origin, so copilot history is available for replay and diagnostics without becoming an ordinary conversation. The model route is read from `ctx.agentDefaultModel.currentSelection()`, calls use `purpose: 'knowledge-copilot'`, and the tool list is always empty.

## Context policy

The default hard input budget is 4096 estimated tokens, with at most 6 smart notes and 700 estimated tokens per excerpt. Sources are assembled in this order: current selection, current note, explicitly selected notes, then ranked smart notes. Ranking combines title matches, shared tags, one-hop links and backlinks, and full-text occurrences. `ctx.tokenMeter.estimateMessage()` prices the exact final user message after each addition; excerpts are shortened at paragraph boundaries and lower-priority smart notes are omitted when they do not fit.

Configuration fields are optional positive safe integers:

| Key | Default | Meaning |
|---|---:|---|
| `maxContextTokens` | 4096 | Hard cap for the exact model-visible user message. |
| `maxSmartNotes` | 6 | Maximum automatically selected related notes. |
| `maxExcerptTokens` | 700 | Approximate per-source excerpt allowance before exact whole-message pricing. |
| `maxQuestionBytes` | 32768 | UTF-8 request question limit. |
| `maxProposalBytes` | 2097152 | UTF-8 model-output limit before diff construction. |

## Proposal safety

The model must return one complete document inside a fenced `markdown` or `md` block. Stable line hunks carry offsets into the immutable base Markdown. `applyProposal()` rejects unknown or duplicate hunk ids, applies accepted hunks from the end of the document, then calls `knowledge.saveNote()` with the stored base revision. A revision conflict preserves both the disk note and the in-memory proposal for retry or manual merge. Cancellation, provider error, malformed output, and output overflow produce no proposal and no note write.

## Model Experience

### Knowledge copilot request

#### What the model sees

One user message contains the fixed instruction, the user's question, and only the selected excerpts. The source section repeats only for excerpts that fit the hard budget. No vault paths, unrelated notes, tools, or ordinary chat history are included.

##### Knowledge request template

```markdown
You are editing one knowledge note. Use only the explicitly supplied excerpts below. Return a complete revised Markdown document inside one fenced markdown block; do not invent unseen vault content.

Question: <question>

## Source: <title> [<note-id>] (<reason>)
<excerpt>
```

#### Token effect

This is a separate one-shot model call. The complete user message is priced through the shared token meter and cannot exceed `maxContextTokens`; model output remains subject to the selected adapter's limits and `maxProposalBytes`.

#### KV Cache effect

The fixed instruction prefix is reusable, while the question and note excerpts vary per request. Per-note sessions preserve audit history but are not replayed into the next copilot request, preventing token growth from prior turns.

## Known Limitations and Deferred Work

- Smart link distance currently uses direct outgoing links and backlinks; deeper graph traversal is deferred.
- Excerpt selection keeps leading paragraph prefixes rather than semantic sentence windows.
- Proposals are process-local until accepted; durable proposal recovery across a Host restart is deferred, while the exact request and response remain in the session log.
- A complete fenced Markdown document is required; free-form advice without a document is rejected.
