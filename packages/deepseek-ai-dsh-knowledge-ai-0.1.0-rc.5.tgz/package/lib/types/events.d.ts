import type { ContextSource, NoteId, VaultId } from '@deepseek-ai/dsh-knowledge/types';
declare module '@deepseek-ai/dsh-session/types' {
    interface SessionEventMap {
        /** Records the exact note excerpts and estimated token total shown to one knowledge-copilot model request. */
        'knowledge/context': {
            readonly vaultId: VaultId;
            readonly noteId: NoteId;
            readonly sources: readonly ContextSource[];
            readonly totalEstimatedTokens: number;
        };
    }
}
export {};
//# sourceMappingURL=events.d.ts.map