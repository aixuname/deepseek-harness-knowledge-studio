import type { NoteId, NoteView } from '@deepseek-ai/dsh-knowledge/types';
/** Contract describing ranked knowledge candidate in Knowledge Studio. */
export interface RankedKnowledgeCandidate {
    readonly note: NoteView;
    readonly score: number;
    readonly reasons: readonly ('title' | 'shared-tags' | 'link-distance' | 'full-text')[];
}
/** Contract describing rank knowledge candidates input in Knowledge Studio. */
export interface RankKnowledgeCandidatesInput {
    readonly current: NoteView;
    readonly candidates: readonly NoteView[];
    readonly query: string;
    readonly linkDistance?: ReadonlyMap<NoteId, number>;
}
/**
 * Rank knowledge candidates for Knowledge Studio.
 * @param input - The input input.
 * @returns The operation result.
 */
export declare function rankKnowledgeCandidates(input: RankKnowledgeCandidatesInput): RankedKnowledgeCandidate[];
//# sourceMappingURL=ranking.d.ts.map