import type { DiffProposal, KnowledgeRevision, NoteId, VaultId } from '@deepseek-ai/dsh-knowledge/types';
/** Contract describing create diff proposal input in Knowledge Studio. */
export interface CreateDiffProposalInput {
    readonly vaultId: VaultId;
    readonly noteId: NoteId;
    readonly baseRevision: KnowledgeRevision;
    readonly baseMarkdown: string;
    readonly proposedMarkdown: string;
}
/**
 * Create diff proposal for Knowledge Studio.
 * @param input - The input input.
 * @returns The operation result.
 */
export declare function createDiffProposal(input: CreateDiffProposalInput): DiffProposal;
/**
 * Apply accepted hunks for Knowledge Studio.
 * @param proposal - The proposal input.
 * @param acceptedHunkIds - The accepted hunk ids input.
 * @returns The operation result.
 */
export declare function applyAcceptedHunks(proposal: DiffProposal, acceptedHunkIds: readonly string[]): string;
//# sourceMappingURL=diff.d.ts.map