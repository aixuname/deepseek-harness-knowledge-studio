/** Token-budgeted per-note AI copilot for knowledge vaults. @module @deepseek-ai/dsh-knowledge-ai */
import './events.ts';
export * from './context.ts';
export * from './diff.ts';
export * from './ranking.ts';
export * from './session.ts';
export * from './service.ts';
export { KnowledgeAiService as default } from './service.ts';
//# sourceMappingURL=index.d.ts.map