import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import { TypertRemoteService } from '@deepseek-ai/dsh-typert-protocol';
import type { ApplyProposalRequest, ContextPreview, ContextPreviewRequest, CopilotRequest, CopilotTurn, NoteView } from '@deepseek-ai/dsh-knowledge/types';
import { type ContextPolicy } from './context.ts';
import './events.ts';
declare module '@deepseek-ai/cordis' {
    interface Context {
        knowledgeAi: KnowledgeAiService;
    }
}
/** Contract describing knowledge ai config in Knowledge Studio. */
export interface KnowledgeAiConfig {
    readonly maxContextTokens?: number;
    readonly maxSmartNotes?: number;
    readonly maxExcerptTokens?: number;
    readonly maxQuestionBytes?: number;
    readonly maxProposalBytes?: number;
}
/** Contract describing resolved knowledge ai config in Knowledge Studio. */
export interface ResolvedKnowledgeAiConfig extends ContextPolicy {
    readonly maxQuestionBytes: number;
    readonly maxProposalBytes: number;
}
/** Contract describing knowledge ai error code in Knowledge Studio. */
export type KnowledgeAiErrorCode = 'cancelled' | 'invalid-request' | 'model-error' | 'invalid-proposal';
/** Implements knowledge ai error for Knowledge Studio. */
export declare class KnowledgeAiError extends Error {
    readonly code: KnowledgeAiErrorCode;
    constructor(message: string, code: KnowledgeAiErrorCode, options?: ErrorOptions);
}
/**
 * Resolve knowledge ai config for Knowledge Studio.
 * @param config - The config input.
 * @returns The operation result.
 */
export declare function resolveKnowledgeAiConfig(config?: KnowledgeAiConfig): ResolvedKnowledgeAiConfig;
/** Implements knowledge ai service for Knowledge Studio. */
export declare class KnowledgeAiService extends TypertRemoteService {
    static inject: string[];
    static Config: z<KnowledgeAiConfig>;
    /** Config for Knowledge Studio. */
    readonly config: ResolvedKnowledgeAiConfig;
    private readonly proposals;
    constructor(ctx: Context, config?: KnowledgeAiConfig);
    private validatePreview;
    private contextFor;
    /**
     * Preview context for Knowledge Studio.
     * @param request - The request input.
     * @returns The operation result.
     */
    previewContext(request: ContextPreviewRequest): Promise<ContextPreview>;
    /**
     * Send copilot for Knowledge Studio.
     * @param request - The request input.
     * @param signal - The signal input.
     * @returns The operation result.
     */
    sendCopilot(request: CopilotRequest, signal?: AbortSignal): Promise<CopilotTurn>;
    /**
     * Apply proposal for Knowledge Studio.
     * @param request - The request input.
     * @returns The operation result.
     */
    applyProposal(request: ApplyProposalRequest): Promise<NoteView>;
}
export default KnowledgeAiService;
//# sourceMappingURL=service.d.ts.map