import { type Message, type UserMessage } from '@deepseek-ai/dsh-llm';
import type { ContextPreview, NoteView } from '@deepseek-ai/dsh-knowledge/types';
/** Contract describing context policy in Knowledge Studio. */
export interface ContextPolicy {
    readonly maxContextTokens: number;
    readonly maxSmartNotes: number;
    readonly maxExcerptTokens: number;
}
/** Default context policy for Knowledge Studio. */
export declare const DEFAULT_CONTEXT_POLICY: ContextPolicy;
/** Contract describing build context input in Knowledge Studio. */
export interface BuildContextInput {
    readonly question: string;
    readonly selection?: string;
    readonly current: NoteView;
    readonly explicit: readonly NoteView[];
    readonly smart: readonly NoteView[];
    readonly estimateMessage: (message: Message) => number;
    readonly policy?: ContextPolicy;
}
/** Contract describing built context in Knowledge Studio. */
export interface BuiltContext {
    readonly message: UserMessage;
    readonly preview: ContextPreview;
}
/**
 * Build context for Knowledge Studio.
 * @param input - The input input.
 * @returns The operation result.
 */
export declare function buildContext(input: BuildContextInput): BuiltContext;
//# sourceMappingURL=context.d.ts.map