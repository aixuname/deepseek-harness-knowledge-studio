import type { Context } from '@deepseek-ai/cordis';
import { SessionId, type Session } from '@deepseek-ai/dsh-session';
import type { NoteRef } from '@deepseek-ai/dsh-knowledge/types';
/**
 * Knowledge session id for Knowledge Studio.
 * @param ref - The ref input.
 * @returns The operation result.
 */
export declare function knowledgeSessionId(ref: NoteRef): SessionId;
/**
 * Ensure knowledge session for Knowledge Studio.
 * @param ctx - The ctx input.
 * @param ref - The ref input.
 * @returns The operation result.
 */
export declare function ensureKnowledgeSession(ctx: Context, ref: NoteRef): Session;
//# sourceMappingURL=session.d.ts.map