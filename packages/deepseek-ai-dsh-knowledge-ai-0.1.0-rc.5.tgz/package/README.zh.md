# @deepseek-ai/dsh-knowledge-ai

[English](README.md) | 中文

在既有 `knowledge.*` Remote 命名空间下提供 Knowledge Studio AI 助手。它为单个知识点挑选少量、可检查的上下文，把模型实际看到的片段记录到该知识点的隐藏会话中，并返回可审阅的 Markdown 差异提案。生成阶段绝不写入笔记；应用所选差异块时，才会依据提案的基础修订号执行比较并交换保存。

每个知识点拥有一个持久会话标识 `knowledge:<vaultId>:<noteId>`，其 `origin` 为 `knowledge`。Host 的普通聊天列表与搜索会过滤该来源，因此 AI 历史可用于回放和诊断，却不会混入普通对话。模型路由来自 `ctx.agentDefaultModel.currentSelection()`；调用使用 `purpose: 'knowledge-copilot'`，工具列表始终为空。

## 上下文策略

默认输入硬上限为 4096 个估算 token，最多自动加入 6 个相关知识点，每个片段的估算额度为 700 token。来源按以下顺序组装：当前选区、当前笔记、用户明确选择的笔记、排序后的智能相关笔记。排序综合标题匹配、共享标签、一步出链与反链以及全文出现次数。每加入一个来源，都会用 `ctx.tokenMeter.estimateMessage()` 对最终用户消息精确估算；片段优先在段落边界缩短，放不下的低优先级智能来源会被省略。

配置项均为可选的正安全整数：

| 配置项 | 默认值 | 含义 |
|---|---:|---|
| `maxContextTokens` | 4096 | 模型实际可见用户消息的硬上限。 |
| `maxSmartNotes` | 6 | 自动选择的相关知识点最大数量。 |
| `maxExcerptTokens` | 700 | 进行整条消息精确估算前，每个来源的近似片段额度。 |
| `maxQuestionBytes` | 32768 | 用户问题的 UTF-8 字节上限。 |
| `maxProposalBytes` | 2097152 | 构造差异前，模型输出的 UTF-8 字节上限。 |

## 提案安全

模型必须在一个 `markdown` 或 `md` 围栏代码块中返回完整文档。稳定的行级差异块携带相对于不可变基础 Markdown 的偏移量。`applyProposal()` 会拒绝未知或重复的差异块标识，从文档末尾向前应用已接受块，再使用保存的基础修订号调用 `knowledge.saveNote()`。若发生修订冲突，当前磁盘笔记和内存提案都会保留，供重试或手动合并。取消、模型错误、格式错误和输出超限均不会生成提案，也不会写入笔记。

## 模型体验

### 知识点 AI 请求

#### 模型会看到什么

模型只收到一条用户消息，其中包含固定指令、用户问题以及选中的片段。只有能放入硬预算的片段才会重复出现来源区段。不会包含知识库路径、无关知识点、工具或普通聊天历史。

##### 知识请求模板

```markdown
You are editing one knowledge note. Use only the explicitly supplied excerpts below. Return a complete revised Markdown document inside one fenced markdown block; do not invent unseen vault content.

Question: <question>

## Source: <title> [<note-id>] (<reason>)
<excerpt>
```

#### Token 影响

这是一次独立的单次模型调用。完整用户消息由共享 token 计量器估算，绝不会超过 `maxContextTokens`；模型输出还受所选适配器限制和 `maxProposalBytes` 约束。

#### KV Cache 影响

固定指令前缀可复用，而问题与知识点片段会随请求变化。每个知识点的隐藏会话保留审计历史，但不会把旧轮次重新发送到下一次 AI 请求，从而避免 token 随历史不断增长。

## 已知限制与暂缓事项

- 智能链接距离目前只使用直接出链与反链；更深层的图遍历暂缓实现。
- 片段选择保留开头的段落前缀，尚未实现语义句窗。
- 提案在接受前只保存在当前进程中；Host 重启后的提案恢复暂缓实现，但准确的请求与响应仍保存在会话日志中。
- 必须返回完整的围栏 Markdown 文档；只有自由形式建议而没有文档时会被拒绝。
