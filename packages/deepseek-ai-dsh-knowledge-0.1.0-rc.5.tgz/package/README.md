# @deepseek-ai/dsh-knowledge

English | [中文](README.zh.md)

Defines the JSON-safe Knowledge Studio domain, branded identifiers, one-backend registry, structured errors, and the `knowledge.*` Remote contract. Filesystem paths and implementation objects never cross the Remote boundary. Backends own persistence while `KnowledgeService` validates requests and delegates to exactly one registered backend.

Revision-bearing note, per-note canvas, and vault relationship graph mutations provide compare-and-set semantics. A stale note save returns `KNOWLEDGE_REVISION_CONFLICT` with the current disk view and caller draft; a stale graph save preserves the caller's graph draft without overwriting the disk graph. Graph edges never change note Markdown or AI context selection.

## Model Experience

None, as this package defines storage-facing contracts and does not assemble prompts or invoke a model; `dsh-knowledge-ai` owns context selection and model interaction.

#### KV Cache effect

None; no model input is produced.

## Known Limitations and Deferred Work

- This package does not persist data; a backend such as `dsh-knowledge-local` must register before Remote calls are available.
- Search ranking, filesystem containment, attachment storage, canvas and graph encoding, and AI context policy belong to their implementing packages.
