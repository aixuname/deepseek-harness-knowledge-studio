# @deepseek-ai/dsh-knowledge

[English](README.md) | 中文

定义 JSON 安全的 Knowledge Studio 领域模型、品牌化标识符、单后端注册表、结构化错误以及 `knowledge.*` Remote 合同。文件系统路径和实现对象不会穿过 Remote 边界。后端拥有持久化职责，`KnowledgeService` 验证请求并只委派给一个已注册后端。

带修订号的笔记、单篇画布和知识库关系画布修改提供比较并交换语义。过期笔记保存会返回 `KNOWLEDGE_REVISION_CONFLICT`，同时带上当前磁盘视图和调用方草稿；过期图谱保存保留调用方画布草稿，不覆盖磁盘版本。图谱连线不会修改笔记 Markdown 或 AI 上下文选择。

## 模型体验

无，因为本包只定义面向存储的合同，不组装提示词或调用模型；上下文选择与模型交互由 `dsh-knowledge-ai` 拥有。

#### KV Cache 影响

无；本包不生成模型输入。

## 已知限制与暂缓事项

- 本包不持久化数据；Remote 调用可用前，必须由 `dsh-knowledge-local` 等后端完成注册。
- 搜索排序、文件系统边界、附件存储、画布与图谱编码和 AI 上下文策略由各自实现包负责。
