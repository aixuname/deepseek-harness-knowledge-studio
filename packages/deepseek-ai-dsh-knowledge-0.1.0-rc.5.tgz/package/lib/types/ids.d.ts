import type { Branded } from '@deepseek-ai/dsh-brand';
/** Contract describing vault id in Knowledge Studio. */
export type VaultId = Branded<'VaultId'>;
/** Contract describing note id in Knowledge Studio. */
export type NoteId = Branded<'NoteId'>;
/** Contract describing asset id in Knowledge Studio. */
export type AssetId = Branded<'AssetId'>;
/** Contract describing canvas id in Knowledge Studio. */
export type CanvasId = Branded<'CanvasId'>;
/** Contract describing knowledge revision in Knowledge Studio. */
export type KnowledgeRevision = Branded<'KnowledgeRevision'>;
/**
 * Vault id for Knowledge Studio.
 * @param value - The value input.
 * @returns The operation result.
 */
export declare const VaultId: (value: string) => VaultId;
/**
 * Note id for Knowledge Studio.
 * @param value - The value input.
 * @returns The operation result.
 */
export declare const NoteId: (value: string) => NoteId;
/**
 * Asset id for Knowledge Studio.
 * @param value - The value input.
 * @returns The operation result.
 */
export declare const AssetId: (value: string) => AssetId;
/**
 * Canvas id for Knowledge Studio.
 * @param value - The value input.
 * @returns The operation result.
 */
export declare const CanvasId: (value: string) => CanvasId;
/**
 * Knowledge revision for Knowledge Studio.
 * @param value - The value input.
 * @returns The operation result.
 */
export declare const KnowledgeRevision: (value: string) => KnowledgeRevision;
//# sourceMappingURL=ids.d.ts.map