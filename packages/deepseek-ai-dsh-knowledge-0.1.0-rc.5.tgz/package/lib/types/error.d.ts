import type { NoteView } from './types.ts';
/** Contract describing knowledge error code in Knowledge Studio. */
export type KnowledgeErrorCode = 'KNOWLEDGE_BACKEND_EXISTS' | 'KNOWLEDGE_CANVAS_DAMAGED' | 'KNOWLEDGE_GRAPH_DAMAGED' | 'KNOWLEDGE_INVALID_REQUEST' | 'KNOWLEDGE_MEDIA_REJECTED' | 'KNOWLEDGE_NOT_FOUND' | 'KNOWLEDGE_PARSE_ERROR' | 'KNOWLEDGE_PATH_REJECTED' | 'KNOWLEDGE_REVISION_CONFLICT' | 'KNOWLEDGE_UNAVAILABLE';
/** Implements knowledge error for Knowledge Studio. */
export declare class KnowledgeError extends Error {
    readonly code: KnowledgeErrorCode;
    readonly details?: Record<string, unknown> | undefined;
    constructor(message: string, code: KnowledgeErrorCode, details?: Record<string, unknown> | undefined);
    /**
     * Revision conflict for Knowledge Studio.
     * @param disk - The disk input.
     * @param draft - The draft input.
     * @returns The operation result.
     */
    static revisionConflict(disk: NoteView, draft: string): KnowledgeError & {
        disk: NoteView;
        draft: string;
    };
}
//# sourceMappingURL=error.d.ts.map