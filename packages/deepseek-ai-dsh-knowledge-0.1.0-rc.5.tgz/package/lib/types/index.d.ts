/** Revisioned, JSON-safe knowledge domain and backend registry. @module @deepseek-ai/dsh-knowledge */
export * from './ids.ts';
export * from './types.ts';
export * from './error.ts';
export * from './service.ts';
export { KnowledgeService as default } from './service.ts';
//# sourceMappingURL=index.d.ts.map