/** Browser-safe knowledge wire contracts. @module @deepseek-ai/dsh-knowledge/client */
export * from './ids.ts';
export type * from './types.ts';
//# sourceMappingURL=client.d.ts.map