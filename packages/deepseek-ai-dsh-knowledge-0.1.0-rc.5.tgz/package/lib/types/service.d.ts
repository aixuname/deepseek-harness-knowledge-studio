import type { Context } from '@deepseek-ai/cordis';
import { TypertRemoteService } from '@deepseek-ai/dsh-typert-protocol';
import type { AttachmentView, CanvasRef, CanvasView, CreateNoteRequest, GraphView, KnowledgeBackend, NoteLinksView, NoteRef, NoteRevisionRef, NoteSummary, NoteView, OpenVaultRequest, PutAttachmentRequest, RenameNoteRequest, RestoreNoteRequest, SaveCanvasRequest, SaveGraphRequest, SaveNoteRequest, SearchHit, SearchRequest, TrashReceipt, VaultView } from './types.ts';
import type { VaultId } from './ids.ts';
declare module '@deepseek-ai/cordis' {
    interface Context {
        knowledge: KnowledgeService;
    }
}
/** Implements knowledge service for Knowledge Studio. */
export declare class KnowledgeService extends TypertRemoteService {
    private backend;
    constructor(ctx: Context);
    /**
     * Register for Knowledge Studio.
     * @param backend - The backend input.
     * @returns The operation result.
     */
    register(backend: KnowledgeBackend): () => void;
    private requireBackend;
    /**
     * List vaults for Knowledge Studio.
     * @returns The operation result.
     */
    listVaults(): Promise<readonly VaultView[]>;
    /**
     * Open vault for Knowledge Studio.
     * @param request - The request input.
     * @returns The operation result.
     */
    openVault(request: OpenVaultRequest): Promise<VaultView>;
    /**
     * List notes for Knowledge Studio.
     * @param vaultId - The vault id input.
     * @returns The operation result.
     */
    listNotes(vaultId: VaultId): Promise<readonly NoteSummary[]>;
    /**
     * Get note for Knowledge Studio.
     * @param ref - The ref input.
     * @returns The operation result.
     */
    getNote(ref: NoteRef): Promise<NoteView>;
    /**
     * Create note for Knowledge Studio.
     * @param request - The request input.
     * @returns The operation result.
     */
    createNote(request: CreateNoteRequest): Promise<NoteView>;
    /**
     * Save note for Knowledge Studio.
     * @param request - The request input.
     * @returns The operation result.
     */
    saveNote(request: SaveNoteRequest): Promise<NoteView>;
    /**
     * Rename note for Knowledge Studio.
     * @param request - The request input.
     * @returns The operation result.
     */
    renameNote(request: RenameNoteRequest): Promise<NoteView>;
    /**
     * Trash note for Knowledge Studio.
     * @param ref - The ref input.
     * @returns The operation result.
     */
    trashNote(ref: NoteRevisionRef): Promise<TrashReceipt>;
    /**
     * Restore note for Knowledge Studio.
     * @param request - The request input.
     * @returns The operation result.
     */
    restoreNote(request: RestoreNoteRequest): Promise<NoteView>;
    /**
     * Search for Knowledge Studio.
     * @param request - The request input.
     * @returns The operation result.
     */
    search(request: SearchRequest): Promise<readonly SearchHit[]>;
    /**
     * Links for Knowledge Studio.
     * @param ref - The ref input.
     * @returns The operation result.
     */
    links(ref: NoteRef): Promise<NoteLinksView>;
    /**
     * Put attachment for Knowledge Studio.
     * @param request - The request input.
     * @returns The operation result.
     */
    putAttachment(request: PutAttachmentRequest): Promise<AttachmentView>;
    /**
     * Get canvas for Knowledge Studio.
     * @param ref - The ref input.
     * @returns The operation result.
     */
    getCanvas(ref: CanvasRef): Promise<CanvasView>;
    /**
     * Save canvas for Knowledge Studio.
     * @param request - The request input.
     * @returns The operation result.
     */
    saveCanvas(request: SaveCanvasRequest): Promise<CanvasView>;
    /**
     * Get the user-arranged relationship graph for one vault.
     * @param vaultId - The owning vault.
     * @returns The revisioned graph.
     */
    getGraph(vaultId: VaultId): Promise<GraphView>;
    /**
     * Save a relationship graph without changing note Markdown.
     * @param request - The graph and expected revision.
     * @returns The saved graph.
     */
    saveGraph(request: SaveGraphRequest): Promise<GraphView>;
}
//# sourceMappingURL=service.d.ts.map