import type { AssetId, CanvasId, KnowledgeRevision, NoteId, VaultId } from './ids.ts';
export type { AssetId, CanvasId, KnowledgeRevision, NoteId, VaultId } from './ids.ts';
/** Contract describing vault view in Knowledge Studio. */
export interface VaultView {
    readonly id: VaultId;
    readonly name: string;
    readonly createdAt: number;
    readonly updatedAt: number;
}
/** Contract describing open vault request in Knowledge Studio. */
export interface OpenVaultRequest {
    readonly vaultId: VaultId;
}
/** Contract describing note ref in Knowledge Studio. */
export interface NoteRef {
    readonly vaultId: VaultId;
    readonly noteId: NoteId;
}
/** Contract describing note revision ref in Knowledge Studio. */
export interface NoteRevisionRef extends NoteRef {
    readonly revision: KnowledgeRevision;
}
/** Contract describing note view in Knowledge Studio. */
export interface NoteView {
    readonly vaultId: VaultId;
    readonly id: NoteId;
    readonly title: string;
    readonly tags: readonly string[];
    readonly markdown: string;
    readonly createdAt: number;
    readonly updatedAt: number;
    readonly revision: KnowledgeRevision;
}
/** Contract describing note summary in Knowledge Studio. */
export interface NoteSummary extends NoteView {
    readonly excerpt: string;
    readonly outgoingCount: number;
    readonly backlinkCount: number;
}
/** Contract describing create note request in Knowledge Studio. */
export interface CreateNoteRequest {
    readonly vaultId: VaultId;
    readonly title: string;
    readonly markdown?: string;
    readonly tags?: readonly string[];
}
/** Contract describing save note request in Knowledge Studio. */
export interface SaveNoteRequest extends NoteRevisionRef {
    readonly markdown: string;
}
/** Contract describing rename note request in Knowledge Studio. */
export interface RenameNoteRequest extends NoteRevisionRef {
    readonly title: string;
}
/** Contract describing trash receipt in Knowledge Studio. */
export interface TrashReceipt extends NoteRevisionRef {
    readonly trashedAt: number;
}
/** Contract describing restore note request in Knowledge Studio. */
export interface RestoreNoteRequest {
    readonly vaultId: VaultId;
    readonly noteId: NoteId;
}
/** Contract describing search request in Knowledge Studio. */
export interface SearchRequest {
    readonly vaultId: VaultId;
    readonly query: string;
    readonly limit?: number;
}
/** Contract describing search hit in Knowledge Studio. */
export interface SearchHit extends NoteRef {
    readonly title: string;
    readonly excerpt: string;
    readonly score: number;
    readonly updatedAt: number;
}
/** Contract describing wiki link in Knowledge Studio. */
export interface WikiLink {
    readonly label: string;
    readonly targetNoteId?: NoteId;
}
/** Contract describing note links view in Knowledge Studio. */
export interface NoteLinksView extends NoteRef {
    readonly outgoing: readonly WikiLink[];
    readonly backlinks: readonly NoteRef[];
    readonly unresolved: readonly string[];
}
/** Contract describing put attachment request in Knowledge Studio. */
export interface PutAttachmentRequest extends NoteRef {
    readonly name: string;
    readonly mediaType: string;
    readonly bytesBase64: string;
}
/** Contract describing attachment view in Knowledge Studio. */
export interface AttachmentView extends NoteRef {
    readonly id: AssetId;
    readonly name: string;
    readonly mediaType: string;
    readonly url: string;
    readonly size: number;
}
/** Contract describing canvas ref in Knowledge Studio. */
export interface CanvasRef extends NoteRef {
    readonly canvasId?: CanvasId;
}
/** Contract describing canvas view in Knowledge Studio. */
export interface CanvasView extends NoteRef {
    readonly id: CanvasId;
    readonly revision: KnowledgeRevision;
    readonly data: string;
}
/** Contract describing save canvas request in Knowledge Studio. */
export interface SaveCanvasRequest extends NoteRef {
    readonly canvasId: CanvasId;
    readonly revision: KnowledgeRevision;
    readonly data: string;
}
/** One positioned note on a vault relationship graph. */
export interface GraphNode {
    readonly noteId: NoteId;
    readonly x: number;
    readonly y: number;
}
/** One user-defined relationship between two positioned notes. */
export interface GraphEdge {
    readonly id: string;
    readonly source: NoteId;
    readonly target: NoteId;
    readonly label: string;
    readonly directed: boolean;
}
/** Revisioned relationship graph owned by one vault. */
export interface GraphView {
    readonly vaultId: VaultId;
    readonly revision: KnowledgeRevision;
    readonly nodes: readonly GraphNode[];
    readonly edges: readonly GraphEdge[];
}
/** Compare-and-swap graph write; note Markdown is never changed. */
export type SaveGraphRequest = GraphView;
/** Contract describing context reason in Knowledge Studio. */
export type ContextReason = 'current-selection' | 'current-note' | 'explicit' | 'smart';
/** Contract describing context source in Knowledge Studio. */
export interface ContextSource extends NoteRef {
    readonly title: string;
    readonly excerpt: string;
    readonly fullLength: number;
    readonly estimatedTokens: number;
    readonly reason: ContextReason;
    readonly score: number;
}
/** Contract describing context preview request in Knowledge Studio. */
export interface ContextPreviewRequest extends NoteRef {
    readonly question: string;
    readonly selection?: string;
    readonly selectedNoteIds?: readonly NoteId[];
}
/** Contract describing context preview in Knowledge Studio. */
export interface ContextPreview {
    readonly sources: readonly ContextSource[];
    readonly totalEstimatedTokens: number;
    readonly maxContextTokens: number;
}
/** Contract describing copilot message in Knowledge Studio. */
export interface CopilotMessage {
    readonly role: 'user' | 'assistant';
    readonly text: string;
    readonly createdAt: number;
}
/** Contract describing copilot request in Knowledge Studio. */
export interface CopilotRequest extends ContextPreviewRequest {
    readonly expectedRevision: KnowledgeRevision;
}
/** Contract describing diff hunk in Knowledge Studio. */
export interface DiffHunk {
    readonly id: string;
    readonly before: string;
    readonly after: string;
    readonly start: number;
    readonly end: number;
}
/** Contract describing diff proposal in Knowledge Studio. */
export interface DiffProposal extends NoteRef {
    readonly id: string;
    readonly baseRevision: KnowledgeRevision;
    readonly baseMarkdown: string;
    readonly proposedMarkdown: string;
    readonly hunks: readonly DiffHunk[];
}
/** Contract describing copilot turn in Knowledge Studio. */
export interface CopilotTurn {
    readonly messages: readonly CopilotMessage[];
    readonly preview: ContextPreview;
    readonly proposal?: DiffProposal;
}
/** Contract describing apply proposal request in Knowledge Studio. */
export interface ApplyProposalRequest {
    readonly proposalId: string;
    readonly acceptedHunkIds: readonly string[];
}
/** Contract describing revision conflict in Knowledge Studio. */
export interface RevisionConflict {
    readonly code: 'KNOWLEDGE_REVISION_CONFLICT';
    readonly disk: NoteView;
    readonly draft: string;
}
/** Contract describing knowledge backend in Knowledge Studio. */
export interface KnowledgeBackend {
    listVaults(): Promise<readonly VaultView[]>;
    openVault(request: OpenVaultRequest): Promise<VaultView>;
    listNotes(vaultId: VaultId): Promise<readonly NoteSummary[]>;
    getNote(ref: NoteRef): Promise<NoteView>;
    createNote(request: CreateNoteRequest): Promise<NoteView>;
    saveNote(request: SaveNoteRequest): Promise<NoteView>;
    renameNote(request: RenameNoteRequest): Promise<NoteView>;
    trashNote(ref: NoteRevisionRef): Promise<TrashReceipt>;
    restoreNote(request: RestoreNoteRequest): Promise<NoteView>;
    search(request: SearchRequest): Promise<readonly SearchHit[]>;
    links(ref: NoteRef): Promise<NoteLinksView>;
    putAttachment(request: PutAttachmentRequest): Promise<AttachmentView>;
    getCanvas(ref: CanvasRef): Promise<CanvasView>;
    saveCanvas(request: SaveCanvasRequest): Promise<CanvasView>;
    getGraph(vaultId: VaultId): Promise<GraphView>;
    saveGraph(request: SaveGraphRequest): Promise<GraphView>;
}
//# sourceMappingURL=types.d.ts.map