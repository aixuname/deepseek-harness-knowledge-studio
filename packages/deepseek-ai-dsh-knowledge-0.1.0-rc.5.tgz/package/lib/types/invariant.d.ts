import { Context } from '@deepseek-ai/cordis';
export declare const name = "knowledge-invariant";
export declare const inject: string[];
export declare const apply: (ctx: Context) => Promise<() => void>;
/** Probe knowledge contract for Knowledge Studio. */
export declare function probeKnowledgeContract(): Promise<void>;
//# sourceMappingURL=invariant.d.ts.map