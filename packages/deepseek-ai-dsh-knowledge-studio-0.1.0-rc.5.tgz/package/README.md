# Knowledge Studio bundle

English | [中文](README.zh.md)

This package installs an additive Obsidian-style knowledge workspace in DeepSeek Harness. Its five Cordis rows provide a revisioned knowledge service, local Markdown vault, token-budgeted AI copilot, persistent page surface, and Midnight Graph browser UI. Ordinary chat rows stay mounted and unchanged.

## Deployment and use

The Knowledge tab opens a separate, linked-note workspace. A focused Copilot context preview shows exactly which selected note and linked excerpts will be sent and estimates their token cost; ordinary chat history is not sent with every note request. Suggested text is reviewed before it changes a note.

The default vault is `G:\DeepSeek Harness\data\knowledge`; users may choose another validated D: or G: path. Each note is an independent Markdown file. The Copilot previews its exact note excerpts and token estimate before sending a request, and applies changes only after review.

The bundle patch is `cordis.patch.yml`. Removing its rows unloads the feature without deleting vault files or removing chat. Browser bundles use Harness's `window.__ModuleLoader__` factory format. The Knowledge UI owns a guarded font route for installed versions whose Client loader does not serve package assets; image bytes are served only from note-owned vault paths.

The actual target is a read-only copy of the user's multi-plugin C: profile at `G:\DeepSeek Harness\data\dsh-home-original-clone`. Its original 11 bundle rows are preserved; Knowledge Studio adds one bundle and six packages. The original C: profile is not modified. The earlier fresh G: profile remains separate and is not the target.

The six packages are built and packed with `scripts/windows/package-knowledge-studio.ps1`. `scripts/windows/deploy-knowledge-studio.ps1 -ManifestPath <manifest.json> -DryRun` checks the installed `0.1.2-rc.1` protocol, all tarball hashes, and the isolated installed-Web smoke proof before any profile edit. Without `-DryRun`, the script installs through the cloned Web profile manager, preserves the prior profile files and package tarballs under `G:\DeepSeek Harness\data\deployment`, and checks that no core package was replaced. Start the desktop through `G:\DeepSeek Harness\Launch DeepSeek Harness.ps1` to use the cloned multi-plugin profile while keeping desktop, Harness, cache, and temporary data on G:.

Rollback: close Harness, explicitly set `DSH_HOME` to `G:\DeepSeek Harness\data\dsh-home-original-clone`, then remove only the six Knowledge Studio packages with the installed `dsh plugin --profile web remove` command. Never run the removal against the C: original; leave the other plugins and vault untouched. The deployment backup is a reference for targeted recovery, not a profile snapshot to restore blindly after other plugins change.

## Model Experience

### Focused note copilot

#### What the model sees

The `knowledgeAi` service builds a request from the active note, the user's question, and bounded excerpts from explicitly selected or relevant linked notes; unrelated vault notes and ordinary chat history are not included.

#### Token effect

The client previews the exact context and estimated token count before sending. `maxContextTokens`, `maxSmartNotes`, and `maxExcerptTokens` cap automatic retrieval; an accepted diff changes only the target note.

#### KV Cache effect

The model request may change as note revisions or selected context change, so Knowledge Studio does not promise KV-cache reuse across note requests.

## Known Limitations and Deferred Work

- The canvas is a per-note Excalidraw board rather than a global force-directed graph.
- Copilot needs a configured model credential; automated replay tests run without one.
- Vault roots are restricted to validated D: or G: paths in this deployment.
- The copied wallpaper plugin still references an unavailable Steam scene, producing unrelated media 404s in the full browser smoke.
