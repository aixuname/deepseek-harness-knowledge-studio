/**
 * Knowledge Studio's installable Cordis patch carrier. The feature's Host and
 * Client plugins are declared in cordis.patch.yml and own their own lifecycle.
 * @module @deepseek-ai/dsh-knowledge-studio
 */
export {};
//# sourceMappingURL=index.d.ts.map