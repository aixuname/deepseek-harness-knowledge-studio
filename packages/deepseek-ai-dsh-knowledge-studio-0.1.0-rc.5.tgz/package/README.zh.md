# Knowledge Studio 插件包

[English](README.md) | 中文

本包为 DeepSeek Harness 增加独立的 Obsidian 风格知识工作区。五个 Cordis 条目分别提供带版本检查的知识服务、本地 Markdown 知识库、受 Token 预算约束的 AI 助手、持久化页面容器和 Midnight Graph 浏览器界面。原有聊天条目保持挂载且不受改动。

## 部署与使用

“知识库”标签页是与普通聊天独立的双链笔记工作区。AI 助手会预览将发送的当前笔记和关联摘录，并估算 Token 消耗；不会每次附带全部聊天记录。建议文字须经审阅才会修改笔记。

默认知识库位于 `G:\DeepSeek Harness\data\knowledge`；用户也可选择经过验证的 D: 或 G: 路径。每个知识点分别保存为 Markdown 文件。AI 助手会在发送请求前展示实际引用的笔记片段和 Token 估算，修改须经用户审阅后才会应用。

插件补丁是 `cordis.patch.yml`。移除相关条目会卸载功能，但不会删除知识库文件或聊天功能。浏览器构建采用 Harness 的 `window.__ModuleLoader__` 工厂格式。知识库界面自带受限字体路由，兼容尚不提供包资源服务的安装版 Client 加载器；图片字节只从笔记所属知识库路径提供。

实际目标是从用户原有的 C 盘多插件配置只读复制出的 `G:\DeepSeek Harness\data\dsh-home-original-clone`。原有 11 个插件包条目全部保留；知识库增加 1 个插件包和 6 个组件。原 C 盘配置未被修改。先前新建的 G 盘配置仍独立存在，并非最终目标。

用 `scripts/windows/package-knowledge-studio.ps1` 构建六个插件包。执行 `scripts/windows/deploy-knowledge-studio.ps1 -ManifestPath <manifest.json> -DryRun`，会在修改配置前核对安装版 `0.1.2-rc.1` 协议、全部包的哈希和隔离环境中的安装版 Web 冒烟测试凭证。去掉 `-DryRun` 后，脚本通过复制后的 Web 配置管理器安装，把原配置文件及插件包副本保存在 `G:\DeepSeek Harness\data\deployment`，并检查原核心包未被替换。今后请通过 `G:\DeepSeek Harness\Launch DeepSeek Harness.ps1` 启动桌面版，以多插件配置运行，同时让桌面、Harness、缓存和临时数据留在 G 盘。

回退时先关闭 Harness，在当前进程明确将 `DSH_HOME` 指向 `G:\DeepSeek Harness\data\dsh-home-original-clone`，再用安装版的 `dsh plugin --profile web remove` 只卸载六个 Knowledge Studio 包。切勿对 C 盘原配置执行卸载；不要动其他插件和知识库。部署备份供定点恢复参考，不应在后续插件变化后直接整份覆盖配置。

## 模型体验

### 聚焦当前笔记的 AI 助手

#### 模型会看到什么

`knowledgeAi` 服务仅使用当前笔记、用户问题，以及用户明确选择或相关双链笔记的有界摘录构造请求；无关笔记和普通聊天记录不会自动附带。

#### Token 影响

发送前会展示实际上下文与 Token 估算。`maxContextTokens`、`maxSmartNotes` 和 `maxExcerptTokens` 限制自动检索量；接受修改后也只更新目标笔记。

#### KV 缓存影响

笔记版本或所选上下文变化会改变模型请求，因此知识工作室不承诺跨请求复用 KV 缓存。

## 已知限制与后续工作

- 画布是每条笔记独立的 Excalidraw 白板，并非全局力导向关系图。
- AI 助手需要已配置的模型凭据；自动化回放测试不使用密钥。
- 本次部署只允许经过验证的 D: 或 G: 知识库路径。
- 复制的壁纸插件仍指向不存在的 Steam 场景文件，因此完整浏览器检查会出现与知识库无关的媒体 404。
