# @deepseek-ai/dsh-client-ui-knowledge

English | [中文](README.zh.md)

Midnight Graph is an Obsidian-inspired knowledge workspace for DeepSeek Harness. It adds one non-conflicting sidebar action and one persistent application surface, then presents each knowledge point as an independent Markdown note. The layout uses a library column, a focused editor, and a collapsible inspector for outlines, outgoing links, backlinks, and AI context awareness.

The editor uses Milkdown 7.22.1 with CommonMark, GFM, history, clipboard behavior, slash-command building blocks, wiki-link completion, math source, and image paste/drop/picker support. A browser draft is written immediately while Host persistence is debounced for 700 milliseconds and guarded by the note revision. Conflicts show the disk version, the browser draft, and a compact diff before the user chooses a side. Failed image uploads revoke their provisional object URL and leave no broken Markdown reference.

The page is deliberately additive: it registers into `ctx.appSurfaces` and `sidebar.footer.action`, so it does not replace the chat, sidebar browser, settings, or another plugin's footer action. At 1100 pixels the inspector collapses; at 760 pixels the library becomes a 56-pixel rail. The palette, borders, radii, focus states, and reduced-motion behavior form the Midnight Graph visual system.

The library's Relationship canvas is a separate vault-wide view. Users add note cards, drag them or reposition them with arrow keys, connect cards, name and direct edges, and double-click to open a note. The graph autosaves through revisioned Remote methods; leaving the view waits for a save, while a conflict keeps the draft and requires an explicit overwrite choice. Removing a card or edge affects the graph only, not the note or Copilot context. Existing per-note Excalidraw canvases remain available for pictures and free-form shapes.

## Model Experience

### Focused note editing

#### What the model sees

Nothing while browsing, linking, editing, autosaving, or inserting images. Those operations use the knowledge Remote only. When Copilot is invoked by the companion AI surface, `knowledge.previewContext` starts with the active note or selection and returns a user-visible source preview instead of sending the entire vault.

#### Token effect

Ordinary knowledge work uses no model tokens. Copilot requests are bounded by the knowledge AI service and include only ranked, explicitly previewed sources.

#### KV Cache effect

Opening the workspace and switching notes do not alter model requests. Separate note Copilot sessions avoid mixing unrelated notes and keep stable prefixes available for provider caching.

## Known Limitations and Deferred Work

- Wiki-link suggestions currently choose from loaded note summaries and Remote search hits; alias management is deferred.
- Mathematical expressions remain Markdown source in this release rather than receiving a dedicated visual equation node.
- The 56-pixel narrow layout preserves navigation icons; full mobile drawer gestures are deferred.
