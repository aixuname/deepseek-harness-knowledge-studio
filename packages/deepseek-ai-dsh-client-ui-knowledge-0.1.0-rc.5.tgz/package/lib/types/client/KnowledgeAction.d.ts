import type { SidebarFooterActionOwnerProps } from '@deepseek-ai/dsh-client-ui-sidebar/client';
export interface KnowledgeActionInjected {
    readonly open: () => void;
    readonly locale: {
        getSnapshot(): {
            readonly active: string;
        };
        subscribe(listener: () => void): () => void;
    };
}
export type KnowledgeActionProps = SidebarFooterActionOwnerProps & KnowledgeActionInjected;
export declare function KnowledgeAction({ wide, open, locale }: KnowledgeActionProps): import("react").JSX.Element;
//# sourceMappingURL=KnowledgeAction.d.ts.map