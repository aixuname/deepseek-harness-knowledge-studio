import type { AttachmentView, CanvasView, GraphView, KnowledgeRevision, NoteId, NoteLinksView, NoteSummary, NoteView, PutAttachmentRequest, SearchHit, VaultId, VaultView } from '@deepseek-ai/dsh-knowledge/client';
import { type KnowledgeClientState } from './state.ts';
import { type CanvasController } from './canvas/controller.ts';
import { type KnowledgeSnapshot } from './snapshot.ts';
interface RemoteError {
    readonly code: string;
    readonly message: string;
    readonly details?: unknown;
}
type RemoteResponse<T> = {
    readonly ok: true;
    readonly value: T;
} | {
    readonly ok: false;
    readonly error: RemoteError;
};
/** Contract describing knowledge remote in Knowledge Studio. */
export interface KnowledgeRemote {
    listVaults(): Promise<RemoteResponse<readonly VaultView[]>>;
    listNotes(vaultId: VaultId): Promise<RemoteResponse<readonly NoteSummary[]>>;
    getNote(ref: {
        vaultId: VaultId;
        noteId: NoteId;
    }): Promise<RemoteResponse<NoteView>>;
    createNote(request: {
        vaultId: VaultId;
        title: string;
    }): Promise<RemoteResponse<NoteView>>;
    saveNote(request: {
        vaultId: VaultId;
        noteId: NoteId;
        revision: KnowledgeRevision;
        markdown: string;
    }): Promise<RemoteResponse<NoteView>>;
    links(ref: {
        vaultId: VaultId;
        noteId: NoteId;
    }): Promise<RemoteResponse<NoteLinksView>>;
    search(request: {
        vaultId: VaultId;
        query: string;
        limit?: number;
    }): Promise<RemoteResponse<readonly SearchHit[]>>;
    putAttachment(request: PutAttachmentRequest): Promise<RemoteResponse<AttachmentView>>;
    getCanvas(ref: {
        vaultId: VaultId;
        noteId: NoteId;
    }): Promise<RemoteResponse<CanvasView>>;
    saveCanvas(request: {
        vaultId: VaultId;
        noteId: NoteId;
        canvasId: CanvasView['id'];
        revision: KnowledgeRevision;
        data: string;
    }): Promise<RemoteResponse<CanvasView>>;
    getGraph(vaultId: VaultId): Promise<RemoteResponse<GraphView>>;
    saveGraph(request: GraphView): Promise<RemoteResponse<GraphView>>;
}
/** Latest-wins browser projection over the revisioned knowledge Remote. */
export declare class KnowledgeClientStore {
    #private;
    readonly api: KnowledgeRemote;
    /** Store for Knowledge Studio. */
    readonly store: KnowledgeSnapshot<KnowledgeClientState>;
    constructor(api: KnowledgeRemote);
    /** Load for Knowledge Studio. */
    load(): Promise<void>;
    /**
     * Select vault for Knowledge Studio.
     * @param vaultId - The vault id input.
     */
    selectVault(vaultId: VaultId): Promise<void>;
    /**
     * Select note for Knowledge Studio.
     * @param vaultId - The vault id input.
     * @param noteId - The note id input.
     */
    selectNote(vaultId: VaultId, noteId: NoteId): Promise<void>;
    /**
     * Set query for Knowledge Studio.
     * @param query - The query input.
     */
    setQuery(query: string): void;
    /**
     * Create note for Knowledge Studio.
     * @param title - The title input.
     */
    createNote(title: string): Promise<void>;
    /**
     * Edit for Knowledge Studio.
     * @param markdown - The markdown input.
     */
    edit(markdown: string): void;
    /** Save now for Knowledge Studio. */
    saveNow(): Promise<void>;
    /** Retry for Knowledge Studio. */
    retry(): void;
    /**
     * Resolve conflict for Knowledge Studio.
     * @param choice - The choice input.
     */
    resolveConflict(choice: 'disk' | 'draft'): void;
    /**
     * Complete wiki link for Knowledge Studio.
     * @param query - The query input.
     * @returns The operation result.
     */
    completeWikiLink(query: string): Promise<readonly NoteSummary[]>;
    /**
     * Put attachment for Knowledge Studio.
     * @param file - The file input.
     * @returns The operation result.
     */
    putAttachment(file: File): Promise<string>;
    /**
     * Canvas for current for Knowledge Studio.
     * @returns The operation result.
     */
    canvasForCurrent(): Promise<CanvasController>;
    /** Dispose for Knowledge Studio. */
    dispose(): void;
}
export {};
//# sourceMappingURL=api-store.d.ts.map