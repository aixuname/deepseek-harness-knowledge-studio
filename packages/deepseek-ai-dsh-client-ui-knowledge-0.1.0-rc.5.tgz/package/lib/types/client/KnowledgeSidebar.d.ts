import type { KnowledgeClientStore } from './api-store.ts';
import type { KnowledgeClientState } from './state.ts';
export interface KnowledgeSidebarProps {
    readonly state: KnowledgeClientState;
    readonly controller: KnowledgeClientStore;
    readonly onOpenGraph?: () => void;
    readonly graphOpen?: boolean;
}
export declare function KnowledgeSidebar({ state, controller, onOpenGraph, graphOpen }: KnowledgeSidebarProps): import("react").JSX.Element;
//# sourceMappingURL=KnowledgeSidebar.d.ts.map