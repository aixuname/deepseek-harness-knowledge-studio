import type { KnowledgeClientState } from './state.ts';
import type { KnowledgeClientStore } from './api-store.ts';
export declare function KnowledgeInspector({ state, controller }: {
    readonly state: KnowledgeClientState;
    readonly controller: KnowledgeClientStore;
}): import("react").JSX.Element;
//# sourceMappingURL=KnowledgeInspector.d.ts.map