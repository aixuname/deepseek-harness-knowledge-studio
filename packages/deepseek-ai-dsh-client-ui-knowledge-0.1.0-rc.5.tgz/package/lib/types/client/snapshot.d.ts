/** Feature-local observable so the browser package needs no host runtime module. */
export interface KnowledgeSnapshot<T> {
    getSnapshot(): T;
    subscribe(listener: () => void): () => void;
    update(mutator: (draft: T) => void): void;
    set(next: T): void;
}
/**
 * Create knowledge snapshot for Knowledge Studio.
 * @param initial - The initial input.
 * @returns The operation result.
 */
export declare function createKnowledgeSnapshot<T>(initial: T): KnowledgeSnapshot<T>;
//# sourceMappingURL=snapshot.d.ts.map