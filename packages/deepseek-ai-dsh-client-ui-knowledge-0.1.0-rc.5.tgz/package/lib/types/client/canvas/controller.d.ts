import type { CanvasView, KnowledgeRevision, NoteId } from '@deepseek-ai/dsh-knowledge/client';
import type { CanvasDraft, StoredCanvasDocument } from './schema.ts';
interface CanvasRemote {
    saveCanvas(request: {
        vaultId: CanvasView['vaultId'];
        noteId: CanvasView['noteId'];
        canvasId: CanvasView['id'];
        revision: KnowledgeRevision;
        data: string;
    }): Promise<{
        ok: true;
        value: CanvasView;
    } | {
        ok: false;
        error: {
            message: string;
        };
    }>;
}
/** Contract describing canvas snapshot in Knowledge Studio. */
export interface CanvasSnapshot extends CanvasView {
    readonly document: StoredCanvasDocument;
    readonly dirty: boolean;
}
/** Contract describing canvas controller in Knowledge Studio. */
export interface CanvasController {
    getSnapshot(): CanvasSnapshot;
    subscribe(listener: () => void): () => void;
    update(document: CanvasDraft): void;
    save(): Promise<void>;
    openNote(noteId: NoteId): void;
    dispose(): void;
}
/**
 * Create canvas controller for Knowledge Studio.
 * @param remote - The remote input.
 * @param initial - The initial input.
 * @param openNote - The open note input.
 * @returns The operation result.
 */
export declare function createCanvasController(remote: CanvasRemote, initial: CanvasView, openNote: (noteId: NoteId) => void): CanvasController;
export {};
//# sourceMappingURL=controller.d.ts.map