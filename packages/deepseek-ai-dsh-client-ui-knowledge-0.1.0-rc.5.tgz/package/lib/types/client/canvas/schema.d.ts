import type { NoteId } from '@deepseek-ai/dsh-knowledge/client';
/** Contract describing stored canvas element in Knowledge Studio. */
export interface StoredCanvasElement {
    readonly id: string;
    readonly type: string;
    readonly customData?: unknown;
}
/** Contract describing canvas draft in Knowledge Studio. */
export interface CanvasDraft {
    readonly elements: readonly StoredCanvasElement[];
    readonly appState: Readonly<Record<string, unknown>>;
    readonly files: Readonly<Record<string, unknown>>;
}
/** Contract describing stored canvas document in Knowledge Studio. */
export interface StoredCanvasDocument extends CanvasDraft {
    readonly type: 'excalidraw';
    readonly version: 1;
    readonly noteId: NoteId;
}
/** Contract describing knowledge note card in Knowledge Studio. */
export interface KnowledgeNoteCard {
    readonly kind: 'knowledge-note';
    readonly noteId: NoteId;
}
/**
 * Parse canvas for Knowledge Studio.
 * @param data - The data input.
 * @param noteId - The note id input.
 * @returns The operation result.
 */
export declare function parseCanvas(data: string, noteId: NoteId): StoredCanvasDocument;
//# sourceMappingURL=schema.d.ts.map