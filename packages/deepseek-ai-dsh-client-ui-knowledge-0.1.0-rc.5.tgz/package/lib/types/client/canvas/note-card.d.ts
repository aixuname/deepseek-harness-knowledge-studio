import type { NoteId } from '@deepseek-ai/dsh-knowledge/client';
import type { KnowledgeNoteCard, StoredCanvasElement } from './schema.ts';
/**
 * Note card for Knowledge Studio.
 * @param noteId - The note id input.
 * @returns The operation result.
 */
export declare function noteCard(noteId: NoteId): KnowledgeNoteCard;
/**
 * Note id of for Knowledge Studio.
 * @param element - The element input.
 * @returns The operation result.
 */
export declare function noteIdOf(element: StoredCanvasElement): NoteId | undefined;
//# sourceMappingURL=note-card.d.ts.map