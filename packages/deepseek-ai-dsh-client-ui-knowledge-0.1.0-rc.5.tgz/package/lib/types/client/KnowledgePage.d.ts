import type { AppSurfaceProps } from '@deepseek-ai/dsh-client-ui-surface/client';
import type { KnowledgeClientStore } from './api-store.ts';
import { type KnowledgeLanguage } from './copy.tsx';
export interface KnowledgePageProps extends AppSurfaceProps {
    readonly controller: KnowledgeClientStore;
    readonly locale?: KnowledgeLanguage;
}
export declare function KnowledgePage({ close, controller, locale }: KnowledgePageProps): import("react").JSX.Element;
//# sourceMappingURL=KnowledgePage.d.ts.map