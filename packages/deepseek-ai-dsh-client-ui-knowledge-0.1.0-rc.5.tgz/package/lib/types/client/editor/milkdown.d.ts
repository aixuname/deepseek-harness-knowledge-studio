import { Editor } from '@milkdown/kit/core';
/**
 * Create the note-local GFM/CommonMark Milkdown instance.
 * @param root - Container element for the editor.
 * @param markdown - Initial Markdown content.
 * @param readOnly - Whether editing is disabled.
 * @param onChange - Receives changed Markdown.
 * @returns The unmounted editor instance.
 */
export declare function createMarkdownEditor(root: HTMLElement, markdown: string, readOnly: boolean, onChange: (markdown: string) => void): Editor;
/**
 * Reconcile a Host revision without rebuilding the note-local editor.
 * @param editor - Editor to update in place.
 * @param markdown - Replacement Markdown from the Host.
 */
export declare function replaceMarkdown(editor: Editor, markdown: string): void;
//# sourceMappingURL=milkdown.d.ts.map