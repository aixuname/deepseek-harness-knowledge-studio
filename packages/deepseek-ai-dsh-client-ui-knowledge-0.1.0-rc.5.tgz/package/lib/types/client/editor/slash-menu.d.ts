/** Contract describing slash command in Knowledge Studio. */
export interface SlashCommand {
    readonly id: string;
    readonly label: string;
    readonly markdown: string;
}
/** Slash commands for Knowledge Studio. */
export declare const slashCommands: readonly SlashCommand[];
/**
 * Filter slash commands for Knowledge Studio.
 * @param query - The query input.
 * @returns The operation result.
 */
export declare function filterSlashCommands(query: string): readonly SlashCommand[];
//# sourceMappingURL=slash-menu.d.ts.map