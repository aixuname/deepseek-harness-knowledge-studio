import type { NoteId, NoteSummary, VaultId } from '@deepseek-ai/dsh-knowledge/client';
type NoteTarget = Pick<NoteSummary, 'vaultId' | 'id' | 'title'>;
/** The note chrome already shows its title; do not repeat the same leading H1 in reading mode. */
export declare function removeRedundantTitle(markdown: string, title: string): string;
/** Return a target only when a wiki title names exactly one note in this vault. */
export declare function resolveWikiTarget(title: string, notes: readonly NoteTarget[], vaultId: VaultId): NoteId | undefined;
/** Decode a preview-only note id. Ordinary Markdown anchors are not knowledge links. */
export declare function previewAnchorNoteId(href: string): NoteId | undefined;
/** Allow only ordinary web URLs to leave the knowledge surface. */
export declare function externalPreviewHref(href: string): string | undefined;
/** Render wiki syntax as ordinary Markdown links without changing the stored note. */
export declare function prepareWikiPreview(markdown: string, notes: readonly NoteTarget[], vaultId: VaultId): string;
export {};
//# sourceMappingURL=wiki-preview.d.ts.map