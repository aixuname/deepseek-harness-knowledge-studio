/**
 * Wiki link query for Knowledge Studio.
 * @param markdown - The markdown input.
 * @param caret - The caret input.
 * @returns The operation result.
 */
export declare function wikiLinkQuery(markdown: string, caret: number): string | undefined;
/**
 * Insert wiki link for Knowledge Studio.
 * @param markdown - The markdown input.
 * @param caret - The caret input.
 * @param title - The title input.
 * @returns The operation result.
 */
export declare function insertWikiLink(markdown: string, caret: number, title: string): {
    markdown: string;
    caret: number;
};
//# sourceMappingURL=wiki-links.d.ts.map