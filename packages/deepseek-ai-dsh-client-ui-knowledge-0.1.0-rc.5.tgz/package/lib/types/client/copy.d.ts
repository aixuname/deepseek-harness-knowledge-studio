import { type ReactNode } from 'react';
import { type KnowledgeKey } from './locales.ts';
export type KnowledgeLanguage = 'zh' | 'en';
export type KnowledgeTranslate = (key: KnowledgeKey) => string;
/** Bind all visible Knowledge Studio copy to the active Harness language. */
export declare function KnowledgeCopyProvider({ locale, children }: {
    readonly locale: KnowledgeLanguage;
    readonly children: ReactNode;
}): import("react").JSX.Element;
/** Read the selected Knowledge Studio dictionary inside one mounted page. */
export declare function useKnowledgeCopy(): {
    locale: KnowledgeLanguage;
    t: KnowledgeTranslate;
};
//# sourceMappingURL=copy.d.ts.map