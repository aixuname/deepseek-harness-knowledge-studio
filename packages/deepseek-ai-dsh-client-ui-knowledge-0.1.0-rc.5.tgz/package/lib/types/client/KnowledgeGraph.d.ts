import type { NoteId, NoteSummary, VaultId } from '@deepseek-ai/dsh-knowledge/client';
import type { KnowledgeRemote } from './api-store.ts';
import { type GraphController } from './graph/model.ts';
/** Inputs for one vault's user-arranged relationship canvas. */
export interface KnowledgeGraphProps {
    readonly vaultId: VaultId;
    readonly notes: readonly NoteSummary[];
    readonly initialSubjectId?: NoteId | undefined;
    readonly remote: Pick<KnowledgeRemote, 'getGraph' | 'saveGraph'>;
    readonly onClose: () => void;
    readonly onOpenNote: (noteId: NoteId) => void;
    readonly onControllerReady?: (controller: GraphController | undefined) => void;
}
/** Load and display the independent relationship graph for one vault. */
export declare function KnowledgeGraph({ vaultId, notes, initialSubjectId, remote, onClose, onOpenNote, onControllerReady }: KnowledgeGraphProps): import("react").JSX.Element;
//# sourceMappingURL=KnowledgeGraph.d.ts.map