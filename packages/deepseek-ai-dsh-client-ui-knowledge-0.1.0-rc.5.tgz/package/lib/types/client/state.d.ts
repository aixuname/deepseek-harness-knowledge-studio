import type { KnowledgeRevision, NoteId, NoteLinksView, NoteSummary, NoteView, RevisionConflict, VaultId, VaultView } from '@deepseek-ai/dsh-knowledge/client';
/** Contract describing save state in Knowledge Studio. */
export type SaveState = 'clean' | 'dirty' | 'saving' | 'retry' | 'conflict';
/** Contract describing knowledge client state in Knowledge Studio. */
export interface KnowledgeClientState {
    status: 'idle' | 'loading' | 'ready' | 'unavailable' | 'error';
    error?: string | undefined;
    vaults: readonly VaultView[];
    notes: readonly NoteSummary[];
    activeVaultId?: VaultId | undefined;
    activeNote?: NoteView | undefined;
    draft?: string | undefined;
    save: SaveState;
    links?: NoteLinksView | undefined;
    conflict?: RevisionConflict | undefined;
    query: string;
    revision?: KnowledgeRevision | undefined;
}
/** Contract describing select note in Knowledge Studio. */
export interface SelectNote {
    readonly vaultId: VaultId;
    readonly noteId: NoteId;
}
/** Initial knowledge state for Knowledge Studio. */
export declare const initialKnowledgeState: KnowledgeClientState;
//# sourceMappingURL=state.d.ts.map