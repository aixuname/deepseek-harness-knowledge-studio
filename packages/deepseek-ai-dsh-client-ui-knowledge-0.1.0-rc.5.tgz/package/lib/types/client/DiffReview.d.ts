import type { DiffProposal } from '@deepseek-ai/dsh-knowledge/client';
export declare function DiffReview({ proposal, onApply, onClose }: {
    readonly proposal: DiffProposal;
    readonly onApply: (acceptedHunkIds: readonly string[]) => void;
    readonly onClose: () => void;
}): import("react").JSX.Element;
//# sourceMappingURL=DiffReview.d.ts.map