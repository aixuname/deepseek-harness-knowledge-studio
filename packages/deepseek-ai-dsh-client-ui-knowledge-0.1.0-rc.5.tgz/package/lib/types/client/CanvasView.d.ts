import type { CanvasController } from './canvas/controller.ts';
export declare function CanvasView({ controller, fullScreen, onToggleFullScreen }: {
    readonly controller: CanvasController;
    readonly fullScreen?: boolean;
    readonly onToggleFullScreen: () => void;
}): import("react").JSX.Element;
//# sourceMappingURL=CanvasView.d.ts.map