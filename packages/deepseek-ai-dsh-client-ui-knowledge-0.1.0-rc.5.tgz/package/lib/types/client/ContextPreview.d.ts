import type { ContextPreview as Preview } from '@deepseek-ai/dsh-knowledge/client';
export declare function ContextPreview({ preview, onConfirm, onCancel }: {
    readonly preview: Preview;
    readonly onConfirm: () => void;
    readonly onCancel: () => void;
}): import("react").JSX.Element;
//# sourceMappingURL=ContextPreview.d.ts.map