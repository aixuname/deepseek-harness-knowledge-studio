/** Contract describing object url api in Knowledge Studio. */
export interface ObjectUrlApi {
    createObjectURL(blob: Blob): string;
    revokeObjectURL(url: string): void;
}
/** Owns provisional image URLs so failed uploads cannot leave phantom references. */
export declare class ImageController {
    #private;
    private readonly urls;
    constructor(urls?: ObjectUrlApi);
    /**
     * Pending for Knowledge Studio.
     * @returns The operation result.
     */
    pending(): readonly string[];
    /**
     * Upload for Knowledge Studio.
     * @param file - The file input.
     * @param persist - The persist input.
     * @returns The operation result.
     */
    upload(file: File, persist: (file: File) => Promise<string>): Promise<{
        preview: string;
        reference: string;
    }>;
    /** Dispose for Knowledge Studio. */
    dispose(): void;
}
//# sourceMappingURL=ImageController.d.ts.map