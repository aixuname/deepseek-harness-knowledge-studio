import type { NoteId, NoteSummary } from '@deepseek-ai/dsh-knowledge/client';
export interface MarkdownEditorProps {
    readonly noteId: NoteId;
    readonly markdown: string;
    readonly readOnly: boolean;
    readonly onChange: (markdown: string) => void;
    readonly onInsertImage: (file: File) => Promise<string>;
    readonly completeWikiLink: (query: string) => Promise<readonly NoteSummary[]>;
}
/** Milkdown stays note-local; Host revisions reconcile through replaceAll. */
export declare function MarkdownEditor(props: MarkdownEditorProps): import("react").JSX.Element;
//# sourceMappingURL=MarkdownEditor.d.ts.map