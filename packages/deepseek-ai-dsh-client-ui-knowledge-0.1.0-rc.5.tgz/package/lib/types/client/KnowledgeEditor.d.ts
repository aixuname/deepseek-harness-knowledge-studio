import type { KnowledgeClientStore } from './api-store.ts';
import type { KnowledgeClientState } from './state.ts';
export interface KnowledgeEditorProps {
    readonly state: KnowledgeClientState;
    readonly controller: KnowledgeClientStore;
}
export declare function KnowledgeEditor({ state, controller }: KnowledgeEditorProps): import("react").JSX.Element;
//# sourceMappingURL=KnowledgeEditor.d.ts.map