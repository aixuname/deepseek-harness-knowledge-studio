import type { ContextPreview as Preview, CopilotTurn, NoteView } from '@deepseek-ai/dsh-knowledge/client';
interface CopilotRemote {
    previewContext(request: unknown): Promise<{
        ok: true;
        value: Preview;
    } | {
        ok: false;
        error: {
            message: string;
        };
    }>;
    sendCopilot(request: unknown, signal?: AbortSignal): Promise<{
        ok: true;
        value: CopilotTurn;
    } | {
        ok: false;
        error: {
            message: string;
        };
    }>;
    applyProposal(request: unknown): Promise<{
        ok: true;
        value: NoteView;
    } | {
        ok: false;
        error: {
            message: string;
        };
    }>;
}
export declare function CopilotPanel({ api, note, onApplied }: {
    readonly api: CopilotRemote;
    readonly note: NoteView;
    readonly onApplied: () => Promise<void>;
}): import("react").JSX.Element;
export {};
//# sourceMappingURL=CopilotPanel.d.ts.map