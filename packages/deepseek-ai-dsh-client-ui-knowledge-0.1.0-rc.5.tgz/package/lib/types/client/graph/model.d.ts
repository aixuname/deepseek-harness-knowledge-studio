import type { GraphView, NoteId } from '@deepseek-ai/dsh-knowledge/client';
/** Add an existing note to the graph once.
 * @param view Current graph draft.
 * @param noteId Note to place.
 * @returns Updated graph draft.
 */
export declare function addGraphNode(view: GraphView, noteId: NoteId): GraphView;
/** Move one graph node without changing its note.
 * @param view Current graph draft.
 * @param noteId Note to move.
 * @param x Horizontal canvas coordinate.
 * @param y Vertical canvas coordinate.
 * @returns Updated graph draft.
 */
export declare function moveGraphNode(view: GraphView, noteId: NoteId, x: number, y: number): GraphView;
/** Add a directed connection between two placed notes, without duplicating a connection.
 * @param view Current graph draft.
 * @param source Source note.
 * @param target Target note.
 * @param id Unique connection ID.
 * @returns Updated graph draft.
 */
export declare function connectGraphNotes(view: GraphView, source: NoteId, target: NoteId, id: string): GraphView;
/** Edit a connection's label or direction.
 * @param view Current graph draft.
 * @param id Connection ID.
 * @param change Label or direction update.
 * @returns Updated graph draft.
 */
export declare function updateGraphEdge(view: GraphView, id: string, change: {
    label?: string;
    directed?: boolean;
}): GraphView;
/** Remove a connection without removing either note.
 * @param view Current graph draft.
 * @param id Connection ID.
 * @returns Updated graph draft.
 */
export declare function removeGraphEdge(view: GraphView, id: string): GraphView;
/** Remove a graph node and its connections without removing the note.
 * @param view Current graph draft.
 * @param noteId Note to remove from the graph.
 * @returns Updated graph draft.
 */
export declare function removeGraphNode(view: GraphView, noteId: NoteId): GraphView;
/** Observable graph draft, never mixed with Markdown or AI context. */
export interface GraphSnapshot {
    readonly view: GraphView;
    readonly dirty: boolean;
    readonly saving: boolean;
    readonly error?: string | undefined;
    readonly errorCode?: string | undefined;
}
/** Graph editor state and revisioned save operations. */
export interface GraphController {
    getSnapshot(): GraphSnapshot;
    subscribe(listener: () => void): () => void;
    update(change: (view: GraphView) => GraphView): void;
    save(): Promise<void>;
    overwrite(): Promise<void>;
}
/** Create a controller that serializes saves and preserves edits made during a request.
 * @param remote Remote graph read/write operations.
 * @param initial Initially loaded graph.
 * @returns Observable graph controller.
 */
export declare function createGraphController(remote: {
    getGraph(vaultId: GraphView['vaultId']): Promise<{
        ok: true;
        value: GraphView;
    } | {
        ok: false;
        error: {
            message: string;
        };
    }>;
    saveGraph(request: GraphView): Promise<{
        ok: true;
        value: GraphView;
    } | {
        ok: false;
        error: {
            code?: string;
            message: string;
        };
    }>;
}, initial: GraphView): GraphController;
//# sourceMappingURL=model.d.ts.map