import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
import { type KnowledgeKey } from './locales.ts';
export { KnowledgeClientStore } from './api-store.ts';
export type { KnowledgeClientState, SaveState } from './state.ts';
export type { KnowledgeKey } from './locales.ts';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        knowledge: KnowledgeKey;
    }
}
/** Surface, sidebar, copy, and typed knowledge Remote services. */
export declare const inject: string[];
/** Register feature-owned Remote methods, page, and sidebar action. */
export declare function apply(ctx: ClientContext): Promise<() => Promise<void>>;
//# sourceMappingURL=index.d.ts.map