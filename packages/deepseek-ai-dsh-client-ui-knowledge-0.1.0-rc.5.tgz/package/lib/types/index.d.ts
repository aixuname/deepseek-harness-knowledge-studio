import type { Context } from '@deepseek-ai/cordis';
export interface KnowledgeAsset {
    readonly bytes: Buffer;
    readonly contentType: string;
}
/**
 * Read a content-addressed asset emitted into this package.
 * @param hash - Bundle asset directory hash.
 * @param filename - Validated asset filename.
 * @returns The asset bytes and response content type.
 */
export declare function readKnowledgeAsset(hash: string, filename: string): Promise<KnowledgeAsset>;
/** Backwards-compatible font reader retained for existing host-side consumers. */
export declare function readKnowledgeFont(hash: string, filename: string): Promise<Buffer>;
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map